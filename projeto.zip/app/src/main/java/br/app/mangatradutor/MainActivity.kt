package br.app.mangatradutor

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat

class MainActivity : Activity() {

    private val reqCapture = 1
    private val reqNotif = 2

    private lateinit var status: TextView
    private lateinit var spinner: Spinner
    private lateinit var keyBox: EditText
    private lateinit var modelBox: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val d = resources.displayMetrics.density
        fun dp(v: Int): Int = (v * d).toInt()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(20), dp(28), dp(20), dp(28))

        val title = TextView(this)
        title.text = "Tradutor de Mangá"
        title.textSize = 26f
        title.typeface = Typeface.DEFAULT_BOLD
        root.addView(title)

        val how = TextView(this)
        how.text = "Traduz a tela do celular para português e escreve a tradução por cima das falas.\n\n" +
            "1. Escolha o idioma do mangá/manhwa.\n" +
            "2. Toque em Iniciar. Quando o Android perguntar o que compartilhar, escolha \"Tela inteira\".\n" +
            "3. Abra seu leitor. Aparecem botões flutuantes:\n" +
            "   T = traduzir agora (toque de novo para ver o original)\n" +
            "   A = modo automático (traduz sozinho quando você para de rolar)\n" +
            "   ≡ = arrastar os botões de lugar\n" +
            "   ✕ = fechar o tradutor"
        how.textSize = 15f
        how.setPadding(0, dp(12), 0, dp(12))
        root.addView(how)

        val langLabel = TextView(this)
        langLabel.text = "Idioma original:"
        langLabel.typeface = Typeface.DEFAULT_BOLD
        root.addView(langLabel)

        spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            SrcLang.values().map { it.label }
        )
        val prefs = getSharedPreferences("p", MODE_PRIVATE)
        spinner.setSelection(prefs.getInt("lang", 1).coerceIn(0, SrcLang.values().size - 1))
        root.addView(spinner)

        val keyLabel = TextView(this)
        keyLabel.text = "Chave do Gemini (opcional, deixa a tradução bem mais precisa):"
        keyLabel.typeface = Typeface.DEFAULT_BOLD
        keyLabel.setPadding(0, dp(16), 0, 0)
        root.addView(keyLabel)

        keyBox = EditText(this)
        keyBox.hint = "Cole sua chave aqui (deixe vazio para tradução simples)"
        keyBox.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        keyBox.setText(prefs.getString("key", ""))
        root.addView(keyBox)

        val modelLabel = TextView(this)
        modelLabel.text = "Modelo do Gemini (pode deixar como está):"
        root.addView(modelLabel)

        modelBox = EditText(this)
        modelBox.inputType = InputType.TYPE_CLASS_TEXT
        modelBox.setText(prefs.getString("model", "gemini-2.5-flash"))
        root.addView(modelBox)

        val keyHelp = TextView(this)
        keyHelp.text = "Como pegar a chave grátis: abra aistudio.google.com/apikey no Chrome, " +
            "entre com sua conta Google e toque em \"Criar chave de API\". " +
            "Copie e cole acima. Ela fica só neste celular."
        keyHelp.textSize = 13f
        root.addView(keyHelp)

        // ---- Iniciar / parar
        val startBtn = Button(this)
        startBtn.text = "Iniciar tradutor"
        startBtn.setOnClickListener {
            prefs.edit()
                .putInt("lang", spinner.selectedItemPosition)
                .putString("key", keyBox.text.toString().trim())
                .putString("model", modelBox.text.toString().trim())
                .apply()
            refresh()
            start()
        }
        root.addView(startBtn)

        val stopBtn = Button(this)
        stopBtn.text = "Parar tradutor"
        stopBtn.setOnClickListener {
            startService(Intent(this, TranslateService::class.java).setAction(TranslateService.ACTION_STOP))
            toast("Tradutor desligado.")
            refresh()
        }
        root.addView(stopBtn)

        status = TextView(this)
        status.textSize = 14f
        status.setPadding(0, dp(16), 0, 0)
        root.addView(status)

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val overlayOk = Settings.canDrawOverlays(this)
        val hasKey = !getSharedPreferences("p", MODE_PRIVATE).getString("key", "").isNullOrBlank()
        status.text = "Sobrepor outros apps: " + (if (overlayOk) "permitido" else "ainda não permitido") +
            "\nTradução: " + (if (hasKey) "Gemini (precisa) + offline de reserva" else "offline (sem chave)") +
            "\nTradutor: " + (if (TranslateService.running) "ligado" else "desligado")
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    private fun start() {
        if (TranslateService.running) {
            toast("O tradutor já está ligado. Abra seu leitor e use os botões flutuantes.")
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            toast("Ative \"Exibir sobre outros apps\" para o Tradutor e depois volte e toque em Iniciar.")
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), reqNotif)
            return
        }
        askCapture()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == reqNotif) askCapture()
    }

    @Suppress("DEPRECATION")
    private fun askCapture() {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        startActivityForResult(mpm.createScreenCaptureIntent(), reqCapture)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != reqCapture) return
        if (resultCode == RESULT_OK && data != null) {
            val i = Intent(this, TranslateService::class.java)
            i.putExtra(TranslateService.EXTRA_CODE, resultCode)
            i.putExtra(TranslateService.EXTRA_DATA, data)
            i.putExtra(
                TranslateService.EXTRA_LANG,
                SrcLang.values()[spinner.selectedItemPosition].name
            )
            val sp = getSharedPreferences("p", MODE_PRIVATE)
            i.putExtra(TranslateService.EXTRA_KEY, sp.getString("key", "") ?: "")
            i.putExtra(TranslateService.EXTRA_MODEL, sp.getString("model", "") ?: "")
            ContextCompat.startForegroundService(this, i)
            toast("Tradutor ligado! Abra seu leitor de mangá.")
            moveTaskToBack(true)
        } else {
            toast("Sem a permissão de captura não dá para traduzir a tela.")
        }
    }
}
