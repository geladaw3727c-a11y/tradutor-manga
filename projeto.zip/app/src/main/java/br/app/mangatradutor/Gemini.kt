package br.app.mangatradutor

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Traduz os balões de uma página inteira de uma vez com o Gemini (mantém o contexto). */
object Gemini {

    fun translate(key: String, model: String, langName: String, items: List<String>): List<String> {
        val arr = JSONArray()
        for (s in items) arr.put(s)

        val prompt = "You are an expert manga, manhwa and webtoon translator working into Brazilian Portuguese (pt-BR).\n" +
            "Source language: $langName.\n" +
            "Below is a JSON array with the speech bubbles of ONE page, in reading order, extracted by OCR. " +
            "The OCR may contain mistakes, wrong line breaks or missing characters: use the context of the whole page to fix them.\n" +
            "Rules:\n" +
            "- Translate each item into natural, colloquial Brazilian Portuguese, the way a professional scanlation would, " +
            "keeping the character's tone, emotion and personality.\n" +
            "- Keep each translation short, close to the length of the original, because it must fit inside the same bubble.\n" +
            "- Keep proper names the way they are commonly written in Portuguese fan translations.\n" +
            "- If an item is not dialogue or narration (sound effect, watermark, site name, page number, stray symbols), " +
            "return an empty string for it.\n" +
            "- Do not add notes, explanations or quotation marks.\n" +
            "Return ONLY a JSON array of strings with exactly ${items.size} items, in the same order.\n\n" +
            "INPUT:\n" + arr.toString()

        val part = JSONObject().put("text", prompt)
        val content = JSONObject().put("parts", JSONArray().put(part))
        val body = JSONObject()
            .put("contents", JSONArray().put(content))
            .put(
                "generationConfig",
                JSONObject().put("temperature", 0.3).put("responseMimeType", "application/json")
            )

        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/${model.trim()}:generateContent")
        val c = url.openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 60000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("x-goog-api-key", key.trim())
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                val why = when (code) {
                    400, 401, 403 -> "chave inválida ou sem permissão"
                    404 -> "modelo não encontrado"
                    429 -> "limite grátis atingido, espere um pouco"
                    else -> "erro $code"
                }
                throw Exception(why)
            }

            val root = JSONObject(text)
            val parts = root.getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts")
            val sb = StringBuilder()
            for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text", ""))
            var raw = sb.toString().trim()
            val a = raw.indexOf('[')
            val b = raw.lastIndexOf(']')
            if (a < 0 || b <= a) throw Exception("resposta inesperada")
            raw = raw.substring(a, b + 1)

            val out = JSONArray(raw)
            if (out.length() != items.size) throw Exception("resposta incompleta")
            val list = ArrayList<String>()
            for (i in 0 until out.length()) list.add(out.optString(i, "").trim())
            return list
        } finally {
            c.disconnect()
        }
    }
}
