package br.app.mangatradutor

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as WLP
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.Executors
import kotlin.math.abs

/**
 * Serviço que fica rodando: captura a tela, lê o texto, traduz e desenha o português por cima.
 * Mostra 3 botões flutuantes:  ≡ (arrastar)   T (traduzir/ocultar)   A (modo automático)   ✕ (fechar)
 */
class TranslateService : Service() {

    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val EXTRA_LANG = "lang"
        const val EXTRA_KEY = "key"
        const val EXTRA_MODEL = "model"
        const val ACTION_STOP = "br.app.mangatradutor.STOP"
        private const val CHANNEL = "traducao"
        private const val NOTIF_ID = 42

        @Volatile
        var running = false
    }

    private enum class St { WAITING, SHOWN }

    private val handler = Handler(Looper.getMainLooper())

    // Toda a lógica roda em uma única thread, para não haver corrida entre botões e modo automático
    private val logic = Executors.newSingleThreadExecutor().asCoroutineDispatcher()
    private val scope = CoroutineScope(SupervisorJob() + logic)

    private lateinit var wm: WindowManager
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null

    @Volatile
    private var reader: ImageReader? = null

    @Volatile
    private var lastFrame: Bitmap? = null
    private var screenW = 0
    private var screenH = 0

    private var engine: TextEngine? = null
    private var overlay: OverlayView? = null
    private var controlBox: LinearLayout? = null
    private var autoBtn: TextView? = null

    @Volatile
    private var controlRect: Rect? = null

    @Volatile
    private var overlayShown = false

    @Volatile
    private var processing = false
    private var auto = false
    private var autoJob: Job? = null
    private var st = St.WAITING
    private var prevFp: IntArray? = null
    private var stable = 0
    private var settle = 0
    private var awaitingFresh = false
    private var lastToast = ""
    private var lastToastAt = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    @Suppress("DEPRECATION")
    private fun readData(i: Intent?): Intent? =
        if (Build.VERSION.SDK_INT >= 33) i?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        else i?.getParcelableExtra<Intent>(EXTRA_DATA)

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (running) return START_NOT_STICKY

        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, notification)
        }

        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        val data = readData(intent)
        if (data == null) {
            toast("Não consegui iniciar a captura de tela.")
            stopSelf()
            return START_NOT_STICKY
        }
        val lang = try {
            SrcLang.valueOf(intent?.getStringExtra(EXTRA_LANG) ?: "KO")
        } catch (e: Exception) {
            SrcLang.KO
        }

        try {
            val mpm = getSystemService(MediaProjectionManager::class.java)
            val mp = mpm.getMediaProjection(code, data)
            projection = mp
            mp.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    handler.post { stopSelf() }
                }
            }, handler)
            setupCapture()
            addWindows()
        } catch (e: Exception) {
            toast("Erro ao iniciar: ${e.message}")
            stopSelf()
            return START_NOT_STICKY
        }

        val key = intent?.getStringExtra(EXTRA_KEY) ?: ""
        val modelName = (intent?.getStringExtra(EXTRA_MODEL) ?: "").ifBlank { "gemini-2.5-flash" }
        val eng = TextEngine(lang, key, modelName)
        engine = eng
        running = true

        scope.launch {
            try {
                toast("Preparando idioma... (na primeira vez baixa um arquivo, precisa de internet)")
                eng.prepare()
                toast(
                    if (eng.usesGemini) "Pronto com Gemini! Abra seu leitor e toque no botão T."
                    else "Pronto! Abra seu leitor e toque no botão T."
                )
            } catch (e: Exception) {
                toast("Não consegui baixar o idioma. Conecte à internet; vou tentar de novo ao traduzir.")
            }
        }
        return START_NOT_STICKY
    }

    // ---------------------------------------------------------------- captura de tela

    private fun currentBounds(): Rect {
        return if (Build.VERSION.SDK_INT >= 30) {
            wm.maximumWindowMetrics.bounds
        } else {
            val m = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(m)
            Rect(0, 0, m.widthPixels, m.heightPixels)
        }
    }

    private fun setupCapture() {
        val b = currentBounds()
        screenW = b.width()
        screenH = b.height()
        val dpi = resources.displayMetrics.densityDpi
        val newReader = ImageReader.newInstance(screenW, screenH, PixelFormat.RGBA_8888, 2)
        val vd = virtualDisplay
        if (vd == null) {
            virtualDisplay = projection!!.createVirtualDisplay(
                "tradutor-manga", screenW, screenH, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                newReader.surface, null, handler
            )
        } else {
            vd.resize(screenW, screenH, dpi)
            vd.surface = newReader.surface
        }
        val old = reader
        reader = newReader
        lastFrame = null
        old?.close()
    }

    /** Pega o quadro mais recente. Retorna true se chegou um quadro novo. */
    private fun grab(): Boolean {
        val r = reader ?: return false
        val img = (try {
            r.acquireLatestImage()
        } catch (e: Exception) {
            null
        }) ?: return false
        try {
            val plane = img.planes[0]
            val pixelStride = plane.pixelStride
            val rowPadding = plane.rowStride - pixelStride * img.width
            val wide = Bitmap.createBitmap(
                img.width + rowPadding / pixelStride, img.height, Bitmap.Config.ARGB_8888
            )
            wide.copyPixelsFromBuffer(plane.buffer)
            lastFrame = if (rowPadding == 0) {
                wide
            } else {
                val cropped = Bitmap.createBitmap(wide, 0, 0, img.width, img.height)
                wide.recycle()
                cropped
            }
            return true
        } catch (e: Throwable) {
            return false
        } finally {
            img.close()
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // girou a tela: recria a captura no novo tamanho
        handler.postDelayed({
            try {
                setupCapture()
            } catch (e: Exception) {
            }
            scope.launch {
                clearOverlay()
                st = St.WAITING
                stable = 0
                prevFp = null
                awaitingFresh = true
            }
        }, 400)
    }

    // ---------------------------------------------------------------- detecção de mudança (modo automático)

    private fun fingerprint(b: Bitmap): IntArray {
        val cols = 24
        val rows = 48
        val out = IntArray(cols * rows)
        var i = 0
        for (r in 0 until rows) {
            val y = ((r + 0.5f) * b.height / rows).toInt().coerceIn(0, b.height - 1)
            for (c in 0 until cols) {
                val x = ((c + 0.5f) * b.width / cols).toInt().coerceIn(0, b.width - 1)
                val p = b.getPixel(x, y)
                out[i++] = (Color.red(p) * 3 + Color.green(p) * 6 + Color.blue(p)) / 10
            }
        }
        return out
    }

    private fun changed(a: IntArray, b: IntArray): Boolean {
        var n = 0
        for (i in a.indices) if (abs(a[i] - b[i]) > 20) n++
        return n > a.size * 0.006
    }

    private suspend fun tick() {
        if (processing) return
        val fresh = grab()
        if (fresh) awaitingFresh = false
        val frame = lastFrame ?: return
        val fp = fingerprint(frame)

        if (st == St.WAITING) {
            val p = prevFp
            if (p == null || changed(p, fp)) stable = 0 else stable++
            prevFp = fp
            // a tela ficou parada ~0,7 s: traduz
            if (stable >= 2 && !awaitingFresh) process(frame, false)
        } else {
            if (settle > 0) {
                settle--
                prevFp = fp
                return
            }
            val p = prevFp
            if (p != null && changed(p, fp)) {
                // o usuário rolou a página: esconde a tradução antiga e espera parar
                clearOverlay()
                st = St.WAITING
                stable = 0
            }
            prevFp = fp
        }
    }

    // ---------------------------------------------------------------- traduzir

    /** Cor de fundo do balão; retorna null se o fundo for desenho (não é balão liso). */
    private fun sampleBg(b: Bitmap, r: Rect): Int? {
        val m = 4
        val lum = ArrayList<Int>()
        val xs = intArrayOf(r.left - m, r.centerX(), r.right + m)
        val ys = intArrayOf(r.top - m, r.centerY(), r.bottom + m)
        val rr = ArrayList<Int>()
        val gg = ArrayList<Int>()
        val bb = ArrayList<Int>()
        for (xi in 0 until 3) {
            for (yi in 0 until 3) {
                if (xi == 1 && yi == 1) continue
                val px = xs[xi].coerceIn(0, b.width - 1)
                val py = ys[yi].coerceIn(0, b.height - 1)
                val c = b.getPixel(px, py)
                lum.add((Color.red(c) * 3 + Color.green(c) * 6 + Color.blue(c)) / 10)
                rr.add(Color.red(c))
                gg.add(Color.green(c))
                bb.add(Color.blue(c))
            }
        }
        rr.sort()
        gg.sort()
        bb.sort()
        val med = Color.rgb(rr[rr.size / 2], gg[gg.size / 2], bb[bb.size / 2])
        val medLum = (Color.red(med) * 3 + Color.green(med) * 6 + Color.blue(med)) / 10
        val off = lum.count { abs(it - medLum) > 50 }
        return if (off >= 4) null else med
    }

    private suspend fun process(frame: Bitmap, manual: Boolean) {
        if (processing) return
        processing = true
        try {
            val eng = engine ?: return
            if (!eng.ready && !eng.usesGemini) toast("Baixando o idioma... (só na primeira vez)")
            try {
                eng.prepare()
            } catch (e: Exception) {
                toast("Não consegui baixar o idioma. Conecte à internet e tente de novo.")
                return
            }
            withContext(Dispatchers.Main) { updateControlRect() }
            val ignore = listOfNotNull(controlRect)
            val res = eng.run(frame, ignore, (screenH * 0.03f).toInt(), (screenH * 0.97f).toInt())
            val items = res.mapNotNull {
                val bg = sampleBg(frame, it.rect) ?: return@mapNotNull null
                Layouter.build(this, it, bg, screenW, screenH)
            }
            val gerr = eng.geminiError
            if (gerr != null) toast("Gemini falhou ($gerr). Usei a tradução simples.")
            overlayShown = items.isNotEmpty()
            setOverlayItems(items)
            if (items.isEmpty() && manual) toast("Não achei texto nesta tela. Confira o idioma escolhido.")
        } catch (e: Exception) {
            toast("Erro ao traduzir: ${e.message}")
        } finally {
            processing = false
            st = St.SHOWN
            settle = 2
            prevFp = null
        }
    }

    private suspend fun translateNow() {
        if (processing) return
        val hadOverlay = overlayShown
        if (hadOverlay) {
            clearOverlay()
            delay(250)
        }
        var fresh = false
        for (i in 0 until 10) {
            if (grab()) {
                fresh = true
                awaitingFresh = false
            }
            if (fresh || (!hadOverlay && lastFrame != null)) break
            delay(100)
        }
        val frame = lastFrame
        if (frame == null || (hadOverlay && !fresh)) {
            toast("Não consegui capturar a tela. Tente de novo.")
            return
        }
        process(frame, true)
    }

    private fun setOverlayItems(items: List<OverlayView.Item>) {
        handler.post { overlay?.setItems(items) }
    }

    private fun clearOverlay() {
        if (overlayShown) {
            overlayShown = false
            awaitingFresh = true
            setOverlayItems(emptyList())
        }
    }

    // ---------------------------------------------------------------- botões

    private fun onTranslateButton() {
        scope.launch {
            if (!auto && overlayShown) {
                clearOverlay()
                awaitingFresh = false
            } else {
                translateNow()
            }
        }
    }

    private fun toggleAuto() {
        scope.launch {
            if (auto) {
                auto = false
                autoJob?.cancel()
                autoJob = null
            } else {
                auto = true
                st = if (overlayShown) St.SHOWN else St.WAITING
                settle = 2
                stable = 0
                prevFp = null
                autoJob = scope.launch {
                    while (isActive) {
                        delay(350)
                        try {
                            tick()
                        } catch (e: Exception) {
                        }
                    }
                }
            }
            handler.post { updateAutoButton() }
            toast(if (auto) "Modo automático LIGADO: traduz quando você parar de rolar." else "Modo automático desligado.")
        }
    }

    private fun circle(color: Int): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(color)
        return g
    }

    private fun updateAutoButton() {
        autoBtn?.background = circle(if (auto) 0xCC2E7D32.toInt() else 0xCC222222.toInt())
    }

    private fun makeButton(label: String, onClick: () -> Unit): TextView {
        val d = resources.displayMetrics.density
        val tv = TextView(this)
        tv.text = label
        tv.setTextColor(Color.WHITE)
        tv.textSize = 16f
        tv.gravity = Gravity.CENTER
        tv.typeface = Typeface.DEFAULT_BOLD
        tv.background = circle(0xCC222222.toInt())
        val size = (44 * d).toInt()
        val lp = LinearLayout.LayoutParams(size, size)
        lp.setMargins(0, (4 * d).toInt(), 0, 0)
        tv.layoutParams = lp
        tv.setOnClickListener { onClick() }
        return tv
    }

    private fun updateControlRect() {
        val b = controlBox ?: return
        val loc = IntArray(2)
        b.getLocationOnScreen(loc)
        val m = (10 * resources.displayMetrics.density).toInt()
        controlRect = Rect(loc[0] - m, loc[1] - m, loc[0] + b.width + m, loc[1] + b.height + m)
    }

    private fun addWindows() {
        val d = resources.displayMetrics.density

        // 1) camada transparente onde o texto traduzido é desenhado (não recebe toques)
        val ov = OverlayView(this)
        val olp = WLP(
            WLP.MATCH_PARENT, WLP.MATCH_PARENT, WLP.TYPE_APPLICATION_OVERLAY,
            WLP.FLAG_NOT_FOCUSABLE or WLP.FLAG_NOT_TOUCHABLE or
                WLP.FLAG_LAYOUT_IN_SCREEN or WLP.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        olp.gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 30) {
            olp.layoutInDisplayCutoutMode = WLP.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        } else if (Build.VERSION.SDK_INT >= 28) {
            olp.layoutInDisplayCutoutMode = WLP.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm.addView(ov, olp)
        overlay = ov

        // 2) botões flutuantes (ficam por cima)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding((4 * d).toInt(), 0, (4 * d).toInt(), (4 * d).toInt())

        val cp = WLP(
            WLP.WRAP_CONTENT, WLP.WRAP_CONTENT, WLP.TYPE_APPLICATION_OVERLAY,
            WLP.FLAG_NOT_FOCUSABLE or WLP.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        cp.gravity = Gravity.TOP or Gravity.START
        cp.x = screenW - (70 * d).toInt()
        cp.y = screenH / 3
        cp.alpha = 0.8f

        val handle = makeButton("≡") {}
        handle.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0
            var sy = 0
            var tx = 0f
            var ty = 0f
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = cp.x
                        sy = cp.y
                        tx = e.rawX
                        ty = e.rawY
                    }
                    MotionEvent.ACTION_MOVE -> {
                        cp.x = sx + (e.rawX - tx).toInt()
                        cp.y = sy + (e.rawY - ty).toInt()
                        try {
                            wm.updateViewLayout(box, cp)
                        } catch (ex: Exception) {
                        }
                    }
                }
                return true
            }
        })
        (handle.layoutParams as LinearLayout.LayoutParams).setMargins(0, 0, 0, 0)

        box.addView(handle)
        box.addView(makeButton("T") { onTranslateButton() })
        val a = makeButton("A") { toggleAuto() }
        autoBtn = a
        box.addView(a)
        box.addView(makeButton("✕") { stopSelf() })

        wm.addView(box, cp)
        controlBox = box
    }

    // ---------------------------------------------------------------- utilidades

    private fun toast(msg: String) {
        val now = System.currentTimeMillis()
        if (msg == lastToast && now - lastToastAt < 6000) return
        lastToast = msg
        lastToastAt = now
        handler.post { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
    }

    @Suppress("DEPRECATION")
    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Tradução de tela", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, TranslateService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CHANNEL)
            .setContentTitle("Tradutor de Mangá ligado")
            .setContentText("Use os botões flutuantes. Toque em Parar para encerrar.")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Parar", stop)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        running = false
        autoJob?.cancel()
        scope.cancel()
        try {
            overlay?.let { wm.removeView(it) }
        } catch (e: Exception) {
        }
        try {
            controlBox?.let { wm.removeView(it) }
        } catch (e: Exception) {
        }
        overlay = null
        controlBox = null
        try {
            virtualDisplay?.release()
        } catch (e: Exception) {
        }
        try {
            reader?.close()
        } catch (e: Exception) {
        }
        try {
            projection?.stop()
        } catch (e: Exception) {
        }
        engine?.close()
        logic.close()
        super.onDestroy()
    }
}
