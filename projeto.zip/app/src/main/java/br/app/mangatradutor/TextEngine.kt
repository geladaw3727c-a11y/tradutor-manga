package br.app.mangatradutor

import android.graphics.Bitmap
import android.graphics.Rect
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

/** Idiomas de origem que o app entende. */
enum class SrcLang(
    val label: String,
    val code: String,
    val promptName: String,
    val vertical: Boolean,
    val spaced: Boolean
) {
    JA("Japonês (mangá)", TranslateLanguage.JAPANESE, "Japanese", true, false),
    KO("Coreano (manhwa)", TranslateLanguage.KOREAN, "Korean", false, true),
    ZH("Chinês (manhua)", TranslateLanguage.CHINESE, "Chinese", true, false),
    EN("Inglês", TranslateLanguage.ENGLISH, "English", false, true)
}

/** Um balão de fala já traduzido, com a posição original na tela. */
class Translated(val rect: Rect, val text: String, val fontPx: Float)

/** Faz OCR da imagem, agrupa as linhas em balões e traduz para português. */
class TextEngine(
    private val lang: SrcLang,
    private val apiKey: String,
    private val model: String
) {

    val usesGemini: Boolean get() = apiKey.isNotBlank()

    /** Último erro do Gemini (null se deu certo). */
    @Volatile
    var geminiError: String? = null
        private set

    private class Piece(val rect: Rect, val text: String, val vertical: Boolean) {
        val thick: Int get() = if (vertical) rect.width() else rect.height()
    }

    private class Bubble(val rect: Rect, val src: String, val fontPx: Float)

    private val recognizer: TextRecognizer = when (lang) {
        SrcLang.JA -> TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
        SrcLang.KO -> TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
        SrcLang.ZH -> TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
        SrcLang.EN -> TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    private val translator: Translator = Translation.getClient(
        TranslatorOptions.Builder()
            .setSourceLanguage(lang.code)
            .setTargetLanguage(TranslateLanguage.PORTUGUESE)
            .build()
    )

    @Volatile
    var ready = false
        private set

    private val cache = HashMap<String, String>()

    /** Baixa o modelo de tradução offline na primeira vez (precisa de internet). */
    suspend fun prepare() {
        if (ready) return
        try {
            translator.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
            ready = true
        } catch (e: Exception) {
            // com Gemini o modelo offline é só reserva, então não trava
            if (usesGemini) ready = true else throw e
        }
    }

    private fun near(a: Piece, b: Piece): Boolean {
        val gap = (0.6f * minOf(a.thick, b.thick)).toInt()
        val grown = Rect(a.rect)
        grown.inset(-gap, -gap)
        return Rect.intersects(grown, b.rect)
    }

    private suspend fun mlTranslate(s: String): String? = try {
        translator.translate(s).await()
    } catch (e: Exception) {
        null
    }

    suspend fun run(
        bmp: Bitmap,
        ignore: List<Rect>,
        top: Int,
        bottom: Int
    ): List<Translated> {
        val result = recognizer.process(InputImage.fromBitmap(bmp, 0)).await()

        val pieces = ArrayList<Piece>()
        for (block in result.textBlocks) {
            for (line in block.lines) {
                val r = line.boundingBox ?: continue
                val t = line.text.trim()
                if (t.none { it.isLetter() }) continue
                if (r.centerY() < top || r.centerY() > bottom) continue
                if (ignore.any { Rect.intersects(it, r) }) continue
                val vertical = lang.vertical && r.height() > r.width() * 1.4f
                pieces.add(Piece(Rect(r), t, vertical))
            }
        }
        if (pieces.isEmpty()) return emptyList()

        // Junta linhas vizinhas no mesmo balão (union-find)
        val parent = IntArray(pieces.size) { it }
        fun find(x: Int): Int {
            var a = x
            while (parent[a] != a) {
                parent[a] = parent[parent[a]]
                a = parent[a]
            }
            return a
        }
        for (i in pieces.indices) {
            for (j in i + 1 until pieces.size) {
                if (near(pieces[i], pieces[j])) parent[find(i)] = find(j)
            }
        }
        val groups = pieces.indices.groupBy { find(it) }.values

        val thicks = pieces.map { it.thick }.sorted()
        val medAll = thicks[thicks.size / 2]

        val bubbles = ArrayList<Bubble>()
        for (g in groups) {
            val ps = g.map { pieces[it] }
            val box = Rect(ps[0].rect)
            for (p in ps) box.union(p.rect)

            val vertical = ps.any { it.vertical } && ps.count { it.vertical } * 2 >= ps.size
            val ordered = if (vertical) {
                // texto vertical: colunas da direita para a esquerda
                ps.sortedWith(compareByDescending<Piece> { it.rect.centerX() }.thenBy { it.rect.top })
            } else {
                ps.sortedWith(compareBy<Piece> { it.rect.top }.thenBy { it.rect.left })
            }
            val joined = ordered.joinToString(if (lang.spaced) " " else "") { it.text }
            if (joined.count { it.isLetter() } < 2) continue

            val avg = ps.map { it.thick.toFloat() }.average().toFloat()
            // letras muito maiores que as das falas = efeito sonoro, não traduz
            if (pieces.size >= 3 && avg > medAll * 2.2f) continue

            bubbles.add(Bubble(box, joined, avg))
        }
        if (bubbles.isEmpty()) return emptyList()

        // ordem de leitura (o Gemini entende melhor o contexto assim)
        val sorted = bubbles.sortedWith(
            compareBy<Bubble> { it.rect.top / 40 }
                .thenBy { if (lang.vertical) -it.rect.left else it.rect.left }
        )

        if (cache.size > 500) cache.clear()

        val n = sorted.size
        val out = arrayOfNulls<String>(n)
        val todo = ArrayList<Int>()
        for (i in 0 until n) {
            val c = cache[sorted[i].src]
            if (c != null) out[i] = c else todo.add(i)
        }

        if (todo.isNotEmpty()) {
            var geminiOk = false
            if (usesGemini) {
                try {
                    val texts = todo.map { sorted[it].src }
                    val res = withContext(Dispatchers.IO) {
                        Gemini.translate(apiKey, model, lang.promptName, texts)
                    }
                    for (k in todo.indices) {
                        val i = todo[k]
                        out[i] = res[k]
                        cache[sorted[i].src] = res[k]
                    }
                    geminiError = null
                    geminiOk = true
                } catch (e: Exception) {
                    geminiError = e.message ?: "erro"
                }
            }
            if (!geminiOk) {
                for (i in todo) {
                    val s = mlTranslate(sorted[i].src)
                    if (s != null) {
                        out[i] = s
                        cache[sorted[i].src] = s
                    }
                }
            }
        }

        val finalList = ArrayList<Translated>()
        for (i in 0 until n) {
            val t = out[i]?.trim() ?: continue
            if (t.isEmpty()) continue
            finalList.add(Translated(sorted[i].rect, t, sorted[i].fontPx))
        }
        return finalList
    }

    fun close() {
        try {
            recognizer.close()
        } catch (e: Exception) {
        }
        try {
            translator.close()
        } catch (e: Exception) {
        }
    }
}
