package br.app.mangatradutor

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/**
 * Serviço vazio, usado só para desenhar a camada de tradução SEM transparência forçada pelo Android.
 * Ele não lê nada da tela.
 */
class OverlayAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: OverlayAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }
}
