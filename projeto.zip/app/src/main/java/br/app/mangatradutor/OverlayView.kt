package br.app.mangatradutor

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.util.TypedValue
import android.view.View
import kotlin.math.min

/** Tela transparente por cima de tudo que desenha o texto traduzido sobre os balões. */
class OverlayView(context: Context) : View(context) {

    class Item(
        val shapes: List<RectF>,
        val bg: Int,
        val layout: StaticLayout,
        val tx: Float,
        val ty: Float
    )

    @Volatile
    private var items: List<Item> = emptyList()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val loc = IntArray(2)
    private val radius = 12f * resources.displayMetrics.density

    fun setItems(list: List<Item>) {
        items = list
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        getLocationOnScreen(loc)
        canvas.save()
        canvas.translate(-loc[0].toFloat(), -loc[1].toFloat())
        for (item in items) {
            paint.color = item.bg
            for (s in item.shapes) canvas.drawRoundRect(s, radius, radius, paint)
            canvas.save()
            canvas.translate(item.tx, item.ty)
            item.layout.draw(canvas)
            canvas.restore()
        }
        canvas.restore()
    }
}

/** Calcula o tamanho da letra e o formato da caixa para o português caber no balão. */
object Layouter {

    private fun lum(c: Int): Float =
        (0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)) / 255f

    private fun make(text: String, width: Int, size: Float, color: Int): StaticLayout {
        val p = TextPaint(Paint.ANTI_ALIAS_FLAG)
        p.color = color
        p.textSize = size
        p.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        return StaticLayout.Builder.obtain(text, 0, text.length, p, maxOf(width, 20))
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setIncludePad(false)
            .build()
    }

    fun build(
        ctx: Context,
        rect: Rect,
        text: String,
        bg: Int,
        screenW: Int,
        screenH: Int
    ): OverlayView.Item {
        val dm = ctx.resources.displayMetrics
        fun sp(v: Float): Float = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, dm)

        val pad = 5f * dm.density
        val color = if (lum(bg) > 0.5f) Color.BLACK else Color.WHITE
        val boxH = rect.height() + 2 * pad
        val maxW = screenW * 0.94f
        val prefer = sp(13f)
        val low = sp(9f)
        val high = sp(24f)

        var best: StaticLayout? = null
        var bestW = 0
        var bestSize = 0f

        // Se o português não couber no balão original, vai alargando a caixa aos poucos
        for (widen in floatArrayOf(1.0f, 1.3f, 1.7f, 2.2f, 2.8f, 3.5f)) {
            val w = min(rect.width() * widen + 2 * pad, maxW).toInt()
            val inner = w - (2 * pad).toInt()
            var lo = low
            var hi = high
            var found: StaticLayout? = null
            for (i in 0 until 8) {
                val mid = (lo + hi) / 2f
                val l = make(text, inner, mid, color)
                if (l.height <= boxH) {
                    found = l
                    lo = mid
                } else {
                    hi = mid
                }
            }
            val f = found
            if (f != null && lo > bestSize) {
                best = f
                bestW = w
                bestSize = lo
            }
            if (f != null && lo >= prefer) break
        }

        val chosen: StaticLayout
        val w: Int
        val b = best
        if (b != null) {
            chosen = b
            w = bestW
        } else {
            w = min(rect.width() * 3.5f + 2 * pad, maxW).toInt()
            chosen = make(text, w - (2 * pad).toInt(), sp(11f), color)
        }

        val h = chosen.height + 2 * pad
        val cx = rect.exactCenterX()
        val cy = rect.exactCenterY()
        val left = (cx - w / 2f).coerceIn(0f, maxOf(0f, screenW - w.toFloat()))
        val top = (cy - h / 2f).coerceIn(0f, maxOf(0f, screenH - h))

        val orig = RectF(rect)
        orig.inset(-pad, -pad)
        val textRect = RectF(left, top, left + w, top + h)

        return OverlayView.Item(listOf(orig, textRect), bg, chosen, left + pad, top + pad)
    }
}
