package br.app.mangatradutor

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.util.TypedValue
import android.view.View
import kotlin.math.max
import kotlin.math.min

/** Tela transparente por cima de tudo que desenha o texto traduzido sobre os balões. */
class OverlayView(context: Context) : View(context) {

    class Item(
        val shapes: List<RectF>,
        val bg: Int,
        val layout: StaticLayout,
        val tx: Float,
        val ty: Float
    )

    @Volatile
    private var items: List<Item> = emptyList()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val loc = IntArray(2)
    private val radius = 6f * resources.displayMetrics.density

    fun setItems(list: List<Item>) {
        items = list
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        getLocationOnScreen(loc)
        canvas.save()
        canvas.translate(-loc[0].toFloat(), -loc[1].toFloat())
        for (item in items) {
            paint.color = item.bg
            for (s in item.shapes) canvas.drawRoundRect(s, radius, radius, paint)
            canvas.save()
            canvas.translate(item.tx, item.ty)
            item.layout.draw(canvas)
            canvas.restore()
        }
        canvas.restore()
    }
}

/** Calcula o tamanho da letra e a caixa para o português ficar legível e cobrir o texto original. */
object Layouter {

    private fun lum(c: Int): Float =
        (0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)) / 255f

    private fun make(text: String, width: Int, size: Float, color: Int): StaticLayout {
        val p = TextPaint(Paint.ANTI_ALIAS_FLAG)
        p.color = color
        p.textSize = size
        p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        return StaticLayout.Builder.obtain(text, 0, text.length, p, max(width, 20))
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setIncludePad(false)
            .setLineSpacing(0f, 0.95f)
            .build()
    }

    fun build(
        ctx: Context,
        t: Translated,
        bg: Int,
        screenW: Int,
        screenH: Int,
        sizeSp: Int
    ): OverlayView.Item {
        val dm = ctx.resources.displayMetrics
        val d = dm.density
        val rect = t.rect
        val text = t.text
        val color = if (lum(bg) > 0.5f) Color.BLACK else Color.WHITE

        // tamanho escolhido pelo usuário (em sp); balões com letra original grande ganham um pouco mais
        val sliderPx = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, sizeSp.toFloat(), dm)
        val target = max(sliderPx, min(t.fontPx * 0.85f, sliderPx * 1.6f))
        val minSize = target * 0.6f

        val cover = max(3f * d, t.fontPx * 0.45f)
        val pad = max(3f * d, target * 0.3f)

        val tall = rect.height() > rect.width() * 1.5f
        var baseW = if (tall) max(rect.width().toFloat(), rect.height() * 0.5f) else rect.width().toFloat()
        baseW = max(baseW, target * 4f)
        val boxH = max(rect.height() * 1.5f, target * 2.6f)
        val maxW = screenW * 0.9f

        fun fit(ww: Int): StaticLayout? {
            val first = make(text, ww, target, color)
            if (first.height <= boxH) return first
            var lo = minSize
            var hi = target
            var found: StaticLayout? = null
            for (i in 0 until 7) {
                val mid = (lo + hi) / 2f
                val l = make(text, ww, mid, color)
                if (l.height <= boxH) {
                    found = l
                    lo = mid
                } else {
                    hi = mid
                }
            }
            return found
        }

        var best: StaticLayout? = null
        var bestSize = 0f
        var bestW = 0
        for (widen in floatArrayOf(1.2f, 1.5f, 1.9f, 2.4f, 3.0f)) {
            val ww = min(baseW * widen, maxW).toInt()
            val f = fit(ww) ?: continue
            val size = f.paint.textSize
            if (size > bestSize) {
                best = f
                bestSize = size
                bestW = ww
            }
            if (size >= target * 0.9f) break
        }

        val layout: StaticLayout
        val w: Int
        val b = best
        if (b != null) {
            layout = b
            w = bestW
        } else {
            w = min(baseW * 3f, maxW).toInt()
            layout = make(text, w, minSize, color)
        }

        val boxW = w + 2 * pad
        val boxHeight = layout.height + 2 * pad
        val cx = rect.exactCenterX()
        val cy = rect.exactCenterY()
        val left = (cx - boxW / 2f).coerceIn(0f, max(0f, screenW - boxW))
        val top = (cy - boxHeight / 2f).coerceIn(0f, max(0f, screenH - boxHeight))

        // 1) cobre todo o texto original  2) caixa do texto traduzido
        val orig = RectF(rect)
        orig.inset(-cover, -cover)
        val textRect = RectF(left, top, left + boxW, top + boxHeight)

        return OverlayView.Item(listOf(orig, textRect), bg, layout, left + pad, top + pad)
    }
}
