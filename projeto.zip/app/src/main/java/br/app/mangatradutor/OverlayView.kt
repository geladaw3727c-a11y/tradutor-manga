package br.app.mangatradutor

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.view.View
import kotlin.math.max
import kotlin.math.min

/** Tela transparente por cima de tudo que desenha o texto traduzido sobre os balões. */
class OverlayView(context: Context) : View(context) {

    class Item(
        val shapes: List<RectF>,
        val bg: Int,
        val layout: StaticLayout,
        val tx: Float,
        val ty: Float
    )

    @Volatile
    private var items: List<Item> = emptyList()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val loc = IntArray(2)
    private val radius = 6f * resources.displayMetrics.density

    fun setItems(list: List<Item>) {
        items = list
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        getLocationOnScreen(loc)
        canvas.save()
        canvas.translate(-loc[0].toFloat(), -loc[1].toFloat())
        for (item in items) {
            paint.color = item.bg
            for (s in item.shapes) canvas.drawRoundRect(s, radius, radius, paint)
            canvas.save()
            canvas.translate(item.tx, item.ty)
            item.layout.draw(canvas)
            canvas.restore()
        }
        canvas.restore()
    }
}

/** Calcula o tamanho da letra e a caixa para o português caber no balão, com letra parecida com a original. */
object Layouter {

    private fun lum(c: Int): Float =
        (0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)) / 255f

    private fun make(text: String, width: Int, size: Float, color: Int): StaticLayout {
        val p = TextPaint(Paint.ANTI_ALIAS_FLAG)
        p.color = color
        p.textSize = size
        p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        return StaticLayout.Builder.obtain(text, 0, text.length, p, max(width, 20))
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setIncludePad(false)
            .setLineSpacing(0f, 0.95f)
            .build()
    }

    fun build(
        ctx: Context,
        t: Translated,
        bg: Int,
        screenW: Int,
        screenH: Int
    ): OverlayView.Item {
        val d = ctx.resources.displayMetrics.density
        val rect = t.rect
        val text = t.text
        val color = if (lum(bg) > 0.5f) Color.BLACK else Color.WHITE

        // tamanho da letra baseado na altura da letra original (em pixels)
        val maxSize = (t.fontPx * 0.8f).coerceIn(7f, 60f)
        val minSize = max(6f, maxSize * 0.55f)
        val pad = max(2f * d, t.fontPx * 0.2f)

        val tall = rect.height() > rect.width() * 1.5f
        val baseW = if (tall) max(rect.width().toFloat(), rect.height() * 0.5f) else rect.width().toFloat()
        val boxH = rect.height() * 1.12f

        fun fit(ww: Int): StaticLayout? {
            val first = make(text, ww, maxSize, color)
            if (first.height <= boxH) return first
            var lo = minSize
            var hi = maxSize
            var found: StaticLayout? = null
            for (i in 0 until 7) {
                val mid = (lo + hi) / 2f
                val l = make(text, ww, mid, color)
                if (l.height <= boxH) {
                    found = l
                    lo = mid
                } else {
                    hi = mid
                }
            }
            return found
        }

        var chosen: StaticLayout? = null
        var w = 0
        // começa no tamanho do balão e só alarga um pouco se o português não couber
        for (widen in floatArrayOf(1.15f, 1.35f, 1.6f, 1.9f)) {
            val ww = min(baseW * widen, screenW * 0.9f).toInt()
            val f = fit(ww)
            if (f != null) {
                chosen = f
                w = ww
                break
            }
        }

        val layout: StaticLayout
        if (chosen != null) {
            layout = chosen
        } else {
            w = min(baseW * 2.2f, screenW * 0.9f).toInt()
            layout = make(text, w, minSize, color)
        }

        val boxW = w + 2 * pad
        val boxHeight = layout.height + 2 * pad
        val cx = rect.exactCenterX()
        val cy = rect.exactCenterY()
        val left = (cx - boxW / 2f).coerceIn(0f, max(0f, screenW - boxW))
        val top = (cy - boxHeight / 2f).coerceIn(0f, max(0f, screenH - boxHeight))

        // 1) cobre o texto original  2) caixa do texto traduzido
        val orig = RectF(rect)
        orig.inset(-pad, -pad)
        val textRect = RectF(left, top, left + boxW, top + boxHeight)

        return OverlayView.Item(listOf(orig, textRect), bg, layout, left + pad, top + pad)
    }
}
